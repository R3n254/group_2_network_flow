"""Push-Relabel (FIFO) algorithm for maximum flow.

Usage: python push_relabel.py [input_file] [-q]
Without a file name the network is read from the terminal.
"""
import sys
from collections import deque

from network import load_network, print_result


def push_relabel(g, s, t, log=None):
    """Runs FIFO push-relabel on g (modifies its residual capacities), returns the max flow value."""
    say = log or (lambda *_: None)
    n = g.n
    name = g.names
    height = [0] * n
    excess = [0] * n
    ptr = [0] * n            # current-edge pointer of every node
    height[s] = n            # step 1: source is lifted to height n
    pushes = relabels = 0

    queue = deque()
    in_queue = [False] * n

    def push(u, e):
        nonlocal pushes
        v = g.to[e]
        amount = min(excess[u], g.cap[e])
        g.cap[e] -= amount
        g.cap[e ^ 1] += amount
        excess[u] -= amount
        excess[v] += amount
        pushes += 1
        say(f"  push {amount} from {name[u]} to {name[v]}")
        if v not in (s, t) and not in_queue[v]:
            queue.append(v)
            in_queue[v] = True

    # step 2: saturate every edge leaving the source
    say(f"Initial: height[{name[s]}] = {n}, saturate all edges leaving {name[s]}")
    for e in g.adj[s]:
        if g.cap[e] > 0:
            excess[s] += g.cap[e]
            push(s, e)

    # step 3: discharge active nodes (excess > 0, not source or sink) in FIFO order
    while queue:
        u = queue.popleft()
        in_queue[u] = False
        while excess[u] > 0:
            if ptr[u] == len(g.adj[u]):
                # no admissible edge left -> relabel
                new_h = 1 + min(height[g.to[e]] for e in g.adj[u] if g.cap[e] > 0)
                say(f"  relabel {name[u]}: height {height[u]} -> {new_h}")
                height[u] = new_h
                ptr[u] = 0
                relabels += 1
            else:
                e = g.adj[u][ptr[u]]
                v = g.to[e]
                if g.cap[e] > 0 and height[u] == height[v] + 1:
                    push(u, e)
                else:
                    ptr[u] += 1

    say(f"\nNo active node left. pushes = {pushes}, relabels = {relabels}")
    return excess[t]


def main():
    args = [a for a in sys.argv[1:] if a != "-q"]
    quiet = "-q" in sys.argv[1:]
    g, s, t = load_network(args[0] if args else None)
    print(f"Push-Relabel Algorithm: {g.n} nodes, source = {g.names[s]}, sink = {g.names[t]}\n")
    flow = push_relabel(g, s, t, None if quiet else print)
    print_result(g, s, t, flow)


if __name__ == "__main__":
    main()
