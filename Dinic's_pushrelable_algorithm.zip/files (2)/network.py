"""Shared helpers: input parsing, residual graph, min-cut and result printing."""
from collections import deque


class FlowGraph:
    """Residual graph. Edge 2k is the k-th real edge, edge 2k+1 is its reverse."""

    def __init__(self, names):
        self.names = list(names)
        self.index = {name: i for i, name in enumerate(self.names)}
        self.n = len(self.names)
        self.adj = [[] for _ in range(self.n)]
        self.to = []    # head of every edge
        self.cap = []   # residual capacity of every edge
        self.orig = []  # original capacity (0 for reverse edges)

    def add_edge(self, u, v, c):
        self.adj[u].append(len(self.to))
        self.to.append(v)
        self.cap.append(c)
        self.orig.append(c)
        self.adj[v].append(len(self.to))
        self.to.append(u)
        self.cap.append(0)
        self.orig.append(0)

    def reset(self):
        """Forget any flow, go back to the original capacities."""
        self.cap = self.orig[:]

    def tail(self, e):
        return self.to[e ^ 1]

    def flow_on(self, e):
        """Flow on a real (even-numbered) edge."""
        return self.orig[e] - self.cap[e]


def parse_network(text):
    """Format: first line '<source> <sink>', then one '<u> <v> <capacity>' per line.
    Text after '#' is ignored. Node names can be any word."""
    rows = []
    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            rows.append(line.split())
    if not rows:
        raise ValueError("input is empty")
    if len(rows[0]) != 2:
        raise ValueError("first line must be: <source> <sink>")
    source, sink = rows[0]
    if source == sink:
        raise ValueError("source and sink must be different nodes")

    names = [source]
    merged = {}
    for row in rows[1:]:
        if len(row) != 3:
            raise ValueError(f"bad edge line: {' '.join(row)!r} (expected: u v capacity)")
        u, v, c = row
        try:
            c = int(c)
        except ValueError:
            raise ValueError(f"capacity must be an integer: {' '.join(row)!r}")
        if c < 0:
            raise ValueError(f"capacity must not be negative: {' '.join(row)!r}")
        for x in (u, v):
            if x not in names:
                names.append(x)
        if u != v:  # self loops never carry useful flow
            merged[(u, v)] = merged.get((u, v), 0) + c  # parallel edges are merged
    if sink not in names:
        names.append(sink)

    g = FlowGraph(names)
    for (u, v), c in merged.items():
        g.add_edge(g.index[u], g.index[v], c)
    return g, g.index[source], g.index[sink]


def load_network(path=None):
    if path:
        with open(path, encoding="utf-8") as f:
            return parse_network(f.read())
    import sys
    return parse_network(sys.stdin.read())


def min_cut(g, s):
    """Nodes reachable from s in the residual graph = source side of a minimum cut."""
    seen = {s}
    q = deque([s])
    while q:
        u = q.popleft()
        for e in g.adj[u]:
            if g.cap[e] > 0 and g.to[e] not in seen:
                seen.add(g.to[e])
                q.append(g.to[e])
    cut_edges = [e for e in range(0, len(g.to), 2)
                 if g.tail(e) in seen and g.to[e] not in seen]
    return seen, cut_edges


def print_result(g, s, t, max_flow):
    print("\nFlow on every edge (flow/capacity)")
    print("----------------------------------")
    for e in range(0, len(g.to), 2):
        print(f"{g.names[g.tail(e)]} -> {g.names[g.to[e]]} : {g.flow_on(e)}/{g.orig[e]}")
    seen, cut_edges = min_cut(g, s)
    p = [g.names[i] for i in range(g.n) if i in seen]
    p2 = [g.names[i] for i in range(g.n) if i not in seen]
    print("\nMinimum cut (Max-Flow Min-Cut Theorem)")
    print("--------------------------------------")
    print(f"P  = {{{', '.join(p)}}}")
    print(f"P' = {{{', '.join(p2)}}}")
    parts = [f"{g.names[g.tail(e)]}->{g.names[g.to[e]]} ({g.orig[e]})" for e in cut_edges]
    print(f"Cut edges: {', '.join(parts) if parts else '(none)'}")
    print(f"Cut value: {sum(g.orig[e] for e in cut_edges)}")
    print(f"\nMaximum flow from {g.names[s]} to {g.names[t]}: {max_flow}")
