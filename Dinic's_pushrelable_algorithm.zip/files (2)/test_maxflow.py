import random
import unittest
from collections import deque

from network import parse_network, min_cut
from dinic import dinic
from push_relabel import push_relabel

ALGORITHMS = [("dinic", dinic), ("push_relabel", push_relabel)]

LECTURE = "S T\nS A 5\nS B 2\nA C 2\nA B 2\nB D 4\nD C 1\nC T 3\nD T 5\n"
BIPARTITE = "s t\ns a 1\ns b 1\na c 1\na d 1\nb c 1\nc t 1\nd t 1\n"
CLRS = "s t\ns v1 16\ns v2 13\nv1 v3 12\nv2 v1 4\nv2 v4 14\nv3 v2 9\nv3 t 20\nv4 v3 7\nv4 t 4\n"


def reference_edmonds_karp(g, s, t):
    """Independent BFS-based reference used only to check the two algorithms."""
    g.reset()
    total = 0
    while True:
        parent = {s: None}
        q = deque([s])
        while q and t not in parent:
            u = q.popleft()
            for e in g.adj[u]:
                if g.cap[e] > 0 and g.to[e] not in parent:
                    parent[g.to[e]] = e
                    q.append(g.to[e])
        if t not in parent:
            g.reset()
            return total
        bottleneck, v = float("inf"), t
        while parent[v] is not None:
            bottleneck = min(bottleneck, g.cap[parent[v]])
            v = g.to[parent[v] ^ 1]
        v = t
        while parent[v] is not None:
            g.cap[parent[v]] -= bottleneck
            g.cap[parent[v] ^ 1] += bottleneck
            v = g.to[parent[v] ^ 1]
        total += bottleneck


class FlowChecks(unittest.TestCase):
    def check_valid_flow(self, g, s, t, value):
        balance = [0] * g.n
        for e in range(0, len(g.to), 2):
            f = g.flow_on(e)
            self.assertTrue(0 <= f <= g.orig[e], "capacity constraint violated")
            balance[g.tail(e)] -= f
            balance[g.to[e]] += f
        for v in range(g.n):
            if v not in (s, t):
                self.assertEqual(balance[v], 0, "flow conservation violated")
        self.assertEqual(balance[t], value)
        self.assertEqual(-balance[s], value)

    def check_min_cut(self, g, s, t, value):
        seen, cut_edges = min_cut(g, s)
        self.assertIn(s, seen)
        self.assertNotIn(t, seen)
        self.assertEqual(sum(g.orig[e] for e in cut_edges), value)

    def run_all(self, text, expected):
        for name, algo in ALGORITHMS:
            with self.subTest(algorithm=name):
                g, s, t = parse_network(text)
                value = algo(g, s, t)
                self.assertEqual(value, expected)
                self.check_valid_flow(g, s, t, value)
                self.check_min_cut(g, s, t, value)

    def test_lecture_example(self):
        self.run_all(LECTURE, 6)

    def test_bipartite_matching(self):
        self.run_all(BIPARTITE, 2)

    def test_clrs_example(self):
        self.run_all(CLRS, 23)

    def test_no_path(self):
        self.run_all("s t\ns a 5\nb t 5\n", 0)

    def test_parallel_and_antiparallel_edges(self):
        self.run_all("s t\ns a 3\ns a 4\na s 2\na t 5\nt a 1\n", 5)

    def test_single_edge(self):
        self.run_all("s t\ns t 7\n", 7)

    def test_zero_capacity_edge(self):
        self.run_all("s t\ns a 0\na t 9\ns t 2\n", 2)

    def test_bad_input(self):
        for bad in ["", "s\n", "s s\n", "s t\ns a x\n", "s t\ns a -1\n", "s t\ns a\n"]:
            with self.assertRaises(ValueError):
                parse_network(bad)

    def test_random_networks_against_reference(self):
        rng = random.Random(2026)
        for _ in range(300):
            n = rng.randint(2, 9)
            lines = [f"0 {n - 1}"]
            for _ in range(rng.randint(0, 25)):
                lines.append(f"{rng.randrange(n)} {rng.randrange(n)} {rng.randint(0, 12)}")
            text = "\n".join(lines)
            g, s, t = parse_network(text)
            expected = reference_edmonds_karp(g, s, t)
            for name, algo in ALGORITHMS:
                g.reset()
                value = algo(g, s, t)
                self.assertEqual(value, expected, f"{name} on:\n{text}")
                self.check_valid_flow(g, s, t, value)
                self.check_min_cut(g, s, t, value)


if __name__ == "__main__":
    unittest.main()
