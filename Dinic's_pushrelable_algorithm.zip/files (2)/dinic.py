"""Dinic's algorithm for maximum flow.

Usage: python dinic.py [input_file] [-q]
Without a file name the network is read from the terminal.
"""
import sys
from collections import deque

from network import load_network, print_result

INF = float("inf")


def build_levels(g, s):
    """BFS on the residual graph: level[v] = number of edges from s to v."""
    level = [-1] * g.n
    level[s] = 0
    q = deque([s])
    while q:
        u = q.popleft()
        for e in g.adj[u]:
            v = g.to[e]
            if g.cap[e] > 0 and level[v] < 0:
                level[v] = level[u] + 1
                q.append(v)
    return level


def send_flow(g, u, t, pushed, level, ptr, trail):
    """DFS that only moves from level k to level k+1. Returns the flow it pushed.
    ptr[u] remembers which edge of u is still worth trying (dead ends are skipped)."""
    if u == t:
        trail.append(u)
        return pushed
    while ptr[u] < len(g.adj[u]):
        e = g.adj[u][ptr[u]]
        v = g.to[e]
        if g.cap[e] > 0 and level[v] == level[u] + 1:
            got = send_flow(g, v, t, min(pushed, g.cap[e]), level, ptr, trail)
            if got > 0:
                g.cap[e] -= got        # use up forward residual capacity
                g.cap[e ^ 1] += got    # open the reverse edge
                trail.append(u)
                return got
        ptr[u] += 1
    return 0


def dinic(g, s, t, log=None):
    """Runs Dinic on g (modifies its residual capacities) and returns the max flow value."""
    sys.setrecursionlimit(max(10000, g.n * 4))
    say = log or (lambda *_: None)
    total, phase = 0, 0
    while True:
        level = build_levels(g, s)
        if level[t] < 0:
            say(f"\nBFS cannot reach {g.names[t]} anymore -> no augmenting path left, flow is maximum.")
            break
        phase += 1
        shown = ", ".join(f"{g.names[v]}={level[v]}" for v in range(g.n) if level[v] >= 0)
        say(f"\nPhase {phase}: level graph  {shown}")
        ptr = [0] * g.n
        phase_flow = 0
        while True:
            trail = []
            pushed = send_flow(g, s, t, INF, level, ptr, trail)
            if pushed == 0:
                break
            path = " -> ".join(g.names[v] for v in reversed(trail))
            say(f"  blocking flow path {path}   (+{pushed})")
            phase_flow += pushed
        total += phase_flow
        say(f"  phase {phase} pushed {phase_flow}, total flow = {total}")
    return total


def main():
    args = [a for a in sys.argv[1:] if a != "-q"]
    quiet = "-q" in sys.argv[1:]
    g, s, t = load_network(args[0] if args else None)
    print(f"Dinic's Algorithm: {g.n} nodes, source = {g.names[s]}, sink = {g.names[t]}")
    flow = dinic(g, s, t, None if quiet else print)
    print_result(g, s, t, flow)


if __name__ == "__main__":
    main()
